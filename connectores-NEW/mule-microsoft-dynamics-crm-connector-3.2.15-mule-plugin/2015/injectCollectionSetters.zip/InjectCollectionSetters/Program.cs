﻿namespace InjectCollectionSetters
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.RegularExpressions;

    class Program
    {
        private const string K_CHECK1 = "This accessor method returns a reference to the live list,";
        private const string K_CHECK2 = "not a snapshot. Therefore any modification you make to the";
        private const string K_CHECK3 = "returned list will be present inside the JAXB object.";

        private const string K_LIST_REGEX = @"public List<(.*)>\sget(.*)\(\)";
        private const string K_BOOLEAN_REGEX = @"public Boolean is([^\(]+)\(\)";
        private const string K_END_REGEX = @"}[^}]*$";

        private static List<String> updatedFiles = new List<string>();

        static void Main(string[] args)
        {
            Console.WriteLine("************************************************************");
            Console.WriteLine("* CRM EXecute operation POJOs checking tool - v1.0 (by mk) *");
            Console.WriteLine("************************************************************");

            var files = Directory.GetFiles("./", "*.java", SearchOption.AllDirectories);

            foreach(var file in files)
            {
                ProcessFile(file);
            }

            if (updatedFiles.Count > 0)
            {
                Console.WriteLine("\nThe following files have been updated:");
                foreach (var updatedFile in updatedFiles)
                {
                    Console.WriteLine("\t- " + updatedFile);
                }
                Console.WriteLine("\n{0} files updated!", updatedFiles.Count);
            } else
            {
                Console.WriteLine("\nEverything looks fine!");
            }

            Console.WriteLine("\n\nPress any key to finish.");
            Console.ReadKey();
        }

        static bool ProcessFile(string file)
        {
            var fileContent = File.ReadAllText(file);

            var listRegex = new Regex(K_LIST_REGEX);
            var booleanRegex = new Regex(K_BOOLEAN_REGEX);
            var endRegex = new Regex(K_END_REGEX);

            var shouldWriteFile = false;
            if (fileContent.Contains(K_CHECK1) && fileContent.Contains(K_CHECK2) && fileContent.Contains(K_CHECK3))
            {
                var listMatch = listRegex.Match(fileContent);
                if (listMatch.Success)
                {
                    var setterName = "set" + listMatch.Groups[2].Value;

                    if (!fileContent.Contains(setterName))
                    {
                        var setterMethod = string.Format(
                            "\tpublic void {0}(List<{1}> value) {{ this.{2} = value; }}\n\n}}",
                            setterName,
                            listMatch.Groups[1].Value,
                            listMatch.Groups[2].Value.Substring(0, 1).ToLowerInvariant() + listMatch.Groups[2].Value.Substring(1));

                        fileContent = endRegex.Replace(fileContent, setterMethod);

                        shouldWriteFile = true;
                    }
                }
            }

            var booleanMatch = booleanRegex.Match(fileContent);
            while (booleanMatch != null && booleanMatch.Success)
            {
                fileContent = fileContent.Replace(booleanMatch.Value, string.Format("public Boolean get{0}()", booleanMatch.Groups[1].Value));

                booleanMatch = booleanMatch.NextMatch();

                shouldWriteFile = true;
            }

            if (shouldWriteFile)
            {
                File.WriteAllText(file, fileContent);
                updatedFiles.Add(file);
            }

            return true;
        }
    }
}
