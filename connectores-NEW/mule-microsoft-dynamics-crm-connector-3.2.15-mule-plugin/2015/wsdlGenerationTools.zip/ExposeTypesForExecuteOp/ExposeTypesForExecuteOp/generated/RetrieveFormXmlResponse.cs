namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class RetrieveFormXmlResponse : Microsoft.Xrm.Sdk.OrganizationResponse, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String FormXml { get; set; }

		[DataMember]
		public System.Int32 CustomizationLevel { get; set; }

		[DataMember]
		public System.Int32 ComponentState { get; set; }

		[DataMember]
		public System.Guid SolutionId { get; set; }
	}
}
