namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class RetrieveMetadataChangesRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.Query.EntityQueryExpression Query { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.Query.DeletedMetadataFilters DeletedMetadataFilters { get; set; }

		[DataMember]
		public System.String ClientVersionStamp { get; set; }
	}
}
