namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class ImportSolutionRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Boolean OverwriteUnmanagedCustomizations { get; set; }

		[DataMember]
		public System.Boolean PublishWorkflows { get; set; }

		[DataMember]
		public System.Byte[] CustomizationFile { get; set; }

		[DataMember]
		public System.Guid ImportJobId { get; set; }

		[DataMember]
		public System.Boolean ConvertToManaged { get; set; }

		[DataMember]
		public System.Boolean SkipProductUpdateDependencies { get; set; }
	}
}
