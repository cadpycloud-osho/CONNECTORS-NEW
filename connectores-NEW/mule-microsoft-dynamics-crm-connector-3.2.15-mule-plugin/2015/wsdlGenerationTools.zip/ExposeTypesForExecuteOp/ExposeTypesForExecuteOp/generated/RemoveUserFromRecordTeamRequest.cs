namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class RemoveUserFromRecordTeamRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference Record { get; set; }

		[DataMember]
		public System.Guid TeamTemplateId { get; set; }

		[DataMember]
		public System.Guid SystemUserId { get; set; }
	}
}
