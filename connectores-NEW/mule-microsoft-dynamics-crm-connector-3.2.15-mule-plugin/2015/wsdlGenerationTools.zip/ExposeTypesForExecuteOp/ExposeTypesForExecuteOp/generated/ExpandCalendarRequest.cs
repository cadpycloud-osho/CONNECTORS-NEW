namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class ExpandCalendarRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid CalendarId { get; set; }

		[DataMember]
		public System.DateTime Start { get; set; }

		[DataMember]
		public System.DateTime End { get; set; }
	}
}
