namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class QualifyLeadRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference LeadId { get; set; }

		[DataMember]
		public System.Boolean CreateAccount { get; set; }

		[DataMember]
		public System.Boolean CreateContact { get; set; }

		[DataMember]
		public System.Boolean CreateOpportunity { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference OpportunityCurrencyId { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference OpportunityCustomerId { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference SourceCampaignId { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.OptionSetValue Status { get; set; }
	}
}
