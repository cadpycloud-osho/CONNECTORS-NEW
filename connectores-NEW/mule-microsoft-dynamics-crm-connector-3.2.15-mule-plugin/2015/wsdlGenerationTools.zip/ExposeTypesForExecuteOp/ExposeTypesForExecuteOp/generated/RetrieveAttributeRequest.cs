namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class RetrieveAttributeRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String EntityLogicalName { get; set; }

		[DataMember]
		public System.String LogicalName { get; set; }

		[DataMember]
		public System.Int32 ColumnNumber { get; set; }

		[DataMember]
		public System.Guid MetadataId { get; set; }

		[DataMember]
		public System.Boolean RetrieveAsIfPublished { get; set; }
	}
}
