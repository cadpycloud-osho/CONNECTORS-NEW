namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class AssociateRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference Target { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Relationship Relationship { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReferenceCollection RelatedEntities { get; set; }
	}
}
