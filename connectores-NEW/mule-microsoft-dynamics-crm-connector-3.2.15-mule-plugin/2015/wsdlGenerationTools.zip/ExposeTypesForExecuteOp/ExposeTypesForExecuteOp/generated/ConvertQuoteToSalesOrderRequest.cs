namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class ConvertQuoteToSalesOrderRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid QuoteId { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Query.ColumnSet ColumnSet { get; set; }

		[DataMember]
		public System.DateTime QuoteCloseDate { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.OptionSetValue QuoteCloseStatus { get; set; }

		[DataMember]
		public System.String QuoteCloseSubject { get; set; }

		[DataMember]
		public System.String QuoteCloseDescription { get; set; }
	}
}
