namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class RetrieveTimestampResponse : Microsoft.Xrm.Sdk.OrganizationResponse, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String Timestamp { get; set; }
	}
}
