namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class RetrievePersonalWallRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Int32 PageNumber { get; set; }

		[DataMember]
		public System.Int32 PageSize { get; set; }

		[DataMember]
		public System.Int32 CommentsPerPost { get; set; }

		[DataMember]
		public System.DateTime StartDate { get; set; }

		[DataMember]
		public System.DateTime EndDate { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.OptionSetValue Type { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.OptionSetValue Source { get; set; }
	}
}
