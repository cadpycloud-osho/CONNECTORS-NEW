namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class RetrieveMembersBulkOperationResponse : Microsoft.Xrm.Sdk.OrganizationResponse, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityCollection EntityCollection { get; set; }
	}
}
