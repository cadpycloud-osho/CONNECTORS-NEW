namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class ExportSolutionRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String SolutionName { get; set; }

		[DataMember]
		public System.Boolean Managed { get; set; }

		[DataMember]
		public System.String TargetVersion { get; set; }

		[DataMember]
		public System.Boolean ExportAutoNumberingSettings { get; set; }

		[DataMember]
		public System.Boolean ExportCalendarSettings { get; set; }

		[DataMember]
		public System.Boolean ExportCustomizationSettings { get; set; }

		[DataMember]
		public System.Boolean ExportEmailTrackingSettings { get; set; }

		[DataMember]
		public System.Boolean ExportGeneralSettings { get; set; }

		[DataMember]
		public System.Boolean ExportMarketingSettings { get; set; }

		[DataMember]
		public System.Boolean ExportOutlookSynchronizationSettings { get; set; }

		[DataMember]
		public System.Boolean ExportRelationshipRoles { get; set; }

		[DataMember]
		public System.Boolean ExportIsvConfig { get; set; }

		[DataMember]
		public System.Boolean ExportSales { get; set; }
	}
}
