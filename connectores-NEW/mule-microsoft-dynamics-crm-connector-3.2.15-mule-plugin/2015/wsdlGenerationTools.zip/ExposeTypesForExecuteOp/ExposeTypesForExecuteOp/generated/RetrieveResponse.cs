namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class RetrieveResponse : Microsoft.Xrm.Sdk.OrganizationResponse, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.Entity Entity { get; set; }

		[DataMember]
		public System.Object Notifications { get; set; }
	}
}
