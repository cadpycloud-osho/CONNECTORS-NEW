namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class CreateActivitiesListRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid ListId { get; set; }

		[DataMember]
		public System.String FriendlyName { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Entity Activity { get; set; }

		[DataMember]
		public System.Guid TemplateId { get; set; }

		[DataMember]
		public System.Boolean Propagate { get; set; }

		[DataMember]
		public Microsoft.Crm.Sdk.Messages.PropagationOwnershipOptions OwnershipOptions { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference Owner { get; set; }

		[DataMember]
		public System.Boolean sendEmail { get; set; }

		[DataMember]
		public System.Boolean PostWorkflowEvent { get; set; }

		[DataMember]
		public System.Guid QueueId { get; set; }
	}
}
