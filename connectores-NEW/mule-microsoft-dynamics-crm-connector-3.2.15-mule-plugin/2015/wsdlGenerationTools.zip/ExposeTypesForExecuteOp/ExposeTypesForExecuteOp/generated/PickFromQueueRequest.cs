namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class PickFromQueueRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid QueueItemId { get; set; }

		[DataMember]
		public System.Guid WorkerId { get; set; }

		[DataMember]
		public System.Boolean RemoveQueueItem { get; set; }
	}
}
