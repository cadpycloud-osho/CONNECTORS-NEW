namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class RetrieveAttributeChangeHistoryRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference Target { get; set; }

		[DataMember]
		public System.String AttributeLogicalName { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Query.PagingInfo PagingInfo { get; set; }
	}
}
