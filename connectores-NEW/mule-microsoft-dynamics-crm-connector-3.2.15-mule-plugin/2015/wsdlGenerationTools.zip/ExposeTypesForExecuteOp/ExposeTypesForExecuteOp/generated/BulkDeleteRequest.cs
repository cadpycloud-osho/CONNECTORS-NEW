namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class BulkDeleteRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.Query.QueryExpression[] QuerySet { get; set; }

		[DataMember]
		public System.String JobName { get; set; }

		[DataMember]
		public System.Boolean SendEmailNotification { get; set; }

		[DataMember]
		public System.Guid[] ToRecipients { get; set; }

		[DataMember]
		public System.Guid[] CCRecipients { get; set; }

		[DataMember]
		public System.String RecurrencePattern { get; set; }

		[DataMember]
		public System.DateTime StartDateTime { get; set; }

		[DataMember]
		public System.Guid? SourceImportId { get; set; }
	}
}
