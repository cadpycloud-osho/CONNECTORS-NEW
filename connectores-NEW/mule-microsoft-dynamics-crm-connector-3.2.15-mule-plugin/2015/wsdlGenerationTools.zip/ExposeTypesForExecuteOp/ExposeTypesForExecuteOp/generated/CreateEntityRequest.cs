namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class CreateEntityRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.EntityMetadata Entity { get; set; }

		[DataMember]
		public System.Boolean HasActivities { get; set; }

		[DataMember]
		public System.Boolean HasNotes { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.StringAttributeMetadata PrimaryAttribute { get; set; }

		[DataMember]
		public System.String SolutionUniqueName { get; set; }
	}
}
