namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class DeleteOptionValueRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String OptionSetName { get; set; }

		[DataMember]
		public System.String AttributeLogicalName { get; set; }

		[DataMember]
		public System.String EntityLogicalName { get; set; }

		[DataMember]
		public System.Int32 Value { get; set; }

		[DataMember]
		public System.String SolutionUniqueName { get; set; }
	}
}
