namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class CleanUpBulkOperationRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid BulkOperationId { get; set; }

		[DataMember]
		public System.Int32 BulkOperationSource { get; set; }
	}
}
