namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class CreateOneToManyRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.LookupAttributeMetadata Lookup { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata OneToManyRelationship { get; set; }

		[DataMember]
		public System.String SolutionUniqueName { get; set; }
	}
}
