namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class ReactivateEntityKeyRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.String EntityKeyLogicalName { get; set; }

		[DataMember]
		public System.String EntityLogicalName { get; set; }
	}
}
