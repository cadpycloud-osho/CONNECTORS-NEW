namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class QueryScheduleRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid ResourceId { get; set; }

		[DataMember]
		public System.DateTime Start { get; set; }

		[DataMember]
		public System.DateTime End { get; set; }

		[DataMember]
		public Microsoft.Crm.Sdk.Messages.TimeCode[] TimeCodes { get; set; }
	}
}
