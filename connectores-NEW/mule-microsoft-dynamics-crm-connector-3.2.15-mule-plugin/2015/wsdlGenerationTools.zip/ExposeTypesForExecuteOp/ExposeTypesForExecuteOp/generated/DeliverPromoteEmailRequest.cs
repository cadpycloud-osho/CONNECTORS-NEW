namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class DeliverPromoteEmailRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid EmailId { get; set; }

		[DataMember]
		public System.String MessageId { get; set; }

		[DataMember]
		public System.String Subject { get; set; }

		[DataMember]
		public System.String From { get; set; }

		[DataMember]
		public System.String To { get; set; }

		[DataMember]
		public System.String Cc { get; set; }

		[DataMember]
		public System.String Bcc { get; set; }

		[DataMember]
		public System.DateTime ReceivedOn { get; set; }

		[DataMember]
		public System.String SubmittedBy { get; set; }

		[DataMember]
		public System.String Importance { get; set; }

		[DataMember]
		public System.String Body { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityCollection Attachments { get; set; }

		[DataMember]
		public Microsoft.Xrm.Sdk.Entity ExtraProperties { get; set; }
	}
}
