namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class BulkOperationStatusCloseRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid BulkOperationId { get; set; }

		[DataMember]
		public System.Int32 FailureCount { get; set; }

		[DataMember]
		public System.Int32 SuccessCount { get; set; }

		[DataMember]
		public System.Int32 StatusReason { get; set; }

		[DataMember]
		public System.Int32 ErrorCode { get; set; }
	}
}
