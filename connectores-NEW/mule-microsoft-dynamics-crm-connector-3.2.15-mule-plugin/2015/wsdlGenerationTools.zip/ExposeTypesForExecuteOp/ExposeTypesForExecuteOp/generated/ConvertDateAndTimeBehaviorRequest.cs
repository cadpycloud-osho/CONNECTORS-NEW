namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class ConvertDateAndTimeBehaviorRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityAttributeCollection Attributes { get; set; }

		[DataMember]
		public System.String ConversionRule { get; set; }

		[DataMember]
		public System.Int32 TimeZoneCode { get; set; }

		[DataMember]
		public System.Boolean AutoConvert { get; set; }
	}
}
