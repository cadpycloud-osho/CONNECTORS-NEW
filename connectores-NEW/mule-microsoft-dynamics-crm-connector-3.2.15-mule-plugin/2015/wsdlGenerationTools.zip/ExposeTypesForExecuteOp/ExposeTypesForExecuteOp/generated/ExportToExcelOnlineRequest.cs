namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class ExportToExcelOnlineRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public Microsoft.Xrm.Sdk.EntityReference View { get; set; }

		[DataMember]
		public System.String FetchXml { get; set; }

		[DataMember]
		public System.String LayoutXml { get; set; }

		[DataMember]
		public System.String QueryApi { get; set; }

		[DataMember]
		public Microsoft.Crm.Sdk.Messages.InputArgumentCollection QueryParameters { get; set; }
	}
}
