namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class QueryMultipleSchedulesRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid[] ResourceIds { get; set; }

		[DataMember]
		public System.DateTime Start { get; set; }

		[DataMember]
		public System.DateTime End { get; set; }

		[DataMember]
		public Microsoft.Crm.Sdk.Messages.TimeCode[] TimeCodes { get; set; }
	}
}
