namespace EnhancedMicrosoft.Crm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/crm/2011/Contracts")]

	public class LogSuccessBulkOperationRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid BulkOperationId { get; set; }

		[DataMember]
		public System.Guid RegardingObjectId { get; set; }

		[DataMember]
		public System.Int32 RegardingObjectTypeCode { get; set; }

		[DataMember]
		public System.Guid CreatedObjectId { get; set; }

		[DataMember]
		public System.Int32 CreatedObjectTypeCode { get; set; }

		[DataMember]
		public System.String AdditionalInfo { get; set; }
	}
}
