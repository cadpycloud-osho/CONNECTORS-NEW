namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class RetrieveEntityKeyRequest : Microsoft.Xrm.Sdk.OrganizationRequest, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid MetadataId { get; set; }

		[DataMember]
		public System.String LogicalName { get; set; }

		[DataMember]
		public System.String EntityLogicalName { get; set; }

		[DataMember]
		public System.Boolean RetrieveAsIfPublished { get; set; }
	}
}
