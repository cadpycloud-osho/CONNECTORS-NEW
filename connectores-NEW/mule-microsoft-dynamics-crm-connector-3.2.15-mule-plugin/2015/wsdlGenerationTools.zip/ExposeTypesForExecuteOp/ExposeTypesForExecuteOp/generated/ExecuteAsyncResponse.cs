namespace EnhancedMicrosoft.Xrm.Sdk.Messages
{
	using System.Runtime.Serialization;

	[DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]

	public class ExecuteAsyncResponse : Microsoft.Xrm.Sdk.OrganizationResponse, System.Runtime.Serialization.IExtensibleDataObject
	{

		[DataMember]
		public System.Guid AsyncJobId { get; set; }
	}
}
