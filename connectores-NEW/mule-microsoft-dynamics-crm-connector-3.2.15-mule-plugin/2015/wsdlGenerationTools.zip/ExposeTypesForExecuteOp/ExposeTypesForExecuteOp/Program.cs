﻿using System;
using System.IO;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            //ServiceHost svcHost = new ServiceHost(typeof(SimpleService), new Uri("http://localhost:8001/MetadataSample"));
            ServiceHost svcHost = new ServiceHost(typeof(ExecuteOperations), new Uri("http://localhost:8001/MetadataSample"));
            try
            {
                // Check to see if the service host already has a ServiceMetadataBehavior
                ServiceMetadataBehavior smb = svcHost.Description.Behaviors.Find<ServiceMetadataBehavior>();
                // If not, add one
                if (smb == null)
                {
                    smb = new ServiceMetadataBehavior();
                    svcHost.Description.Behaviors.Add(smb);
                }
                smb.HttpGetEnabled = true;  
                smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;

                // Add MEX endpoint
                svcHost.AddServiceEndpoint(
                  ServiceMetadataBehavior.MexContractName,
                  MetadataExchangeBindings.CreateMexHttpBinding(),
                  "mex"
                );

                // Add application endpoint
                //svcHost.AddServiceEndpoint(typeof(ISimpleService), new WSHttpBinding(), "");
                var svcEp = svcHost.AddServiceEndpoint(typeof(IExecuteOperations), new BasicHttpBinding(), "");

                //smb.MetadataExporter.ExportEndpoint(svcEp);
                //var metadata = smb.MetadataExporter.GetGeneratedMetadata();

                // Open the service host to accept incoming calls
                svcHost.Open();

                // The service can now be accessed.
                Console.WriteLine("The service is ready.");

                Console.WriteLine("\nDownloading WSDL to file (this might take some time - please wait) ...");
                Directory.CreateDirectory(@".\output");
                using (WebClient client = new WebClient())
                {
                    File.WriteAllText(@".\output\executeOperations.wsdl", client.DownloadString("http://localhost:8001/MetadataSample?singleWsdl"));
                }
                Console.WriteLine("\nWSDL available at 'output' folder");
                Console.WriteLine("\n\nPress <ENTER> to terminate service.");
                Console.ReadLine();

                // Close the ServiceHostBase to shutdown the service.
                svcHost.Close();
            }
            catch (CommunicationException commProblem)
            {
                Console.WriteLine("There was a communication problem. " + commProblem.Message);
                Console.Read();
            }
        }
    }
}
