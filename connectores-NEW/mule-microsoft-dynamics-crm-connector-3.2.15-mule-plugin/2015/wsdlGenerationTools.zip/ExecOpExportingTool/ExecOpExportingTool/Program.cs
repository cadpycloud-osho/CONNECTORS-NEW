﻿namespace ExecOpExportingTool
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Reflection;
    using System.Runtime.Serialization;
    using System.ServiceModel;
    using System.ServiceModel.Description;
    using System.Text;

    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.CSharp;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Messages;

    class Program
    {
        private const int K_LOG_OK = 0;
        private const int K_LOG_INFO = 1;
        private const int K_LOG_WARN = 2;
        private const int K_LOG_ERROR = 3;

        private const string K_SERVICEIMPL = "EXecOps";
        private const string K_SERVICEINTF = "IEXecOps";

        private const string K_SVC_URL = "http://localhost:8001/" + K_SERVICEIMPL;
        private const string K_SVCWSDL = K_SVC_URL + "?singleWsdl";

        private static List<ExportTypeInfo> typesToExport = new List<ExportTypeInfo>();
        private static List<string> warnings = new List<string>();

        static void Main(string[] args)
        {
            Console.WriteLine("*******************************************************");
            Console.WriteLine("* CRM EXecute operation exporting tool - v1.0 (by mk) *");
            Console.WriteLine("*******************************************************");

            try
            {
                var watch = new Stopwatch();
                watch.Start();

                GetTypesToExport();

                ShowWarnings();

                var svcHost = RunService(BuildService(WriteSourceCodeAndInterface()));

                DownloadAndWriteWSDL();

                WriteLog(K_LOG_INFO, string.Format("Total time elapsed: {0} seconds", watch.Elapsed.TotalSeconds));

                Console.WriteLine("\n\nPress <ENTER> to terminate service.");
                Console.ReadLine();

                svcHost.Close();

                DisplayTongue();
            }
            catch (Exception ex)
            {
                WriteLog(K_LOG_ERROR, "There was a problem: " + ex.Message);
                Console.ReadKey();
            }
        }

        private static void GetTypesToExport()
        {
            WriteLog(K_LOG_INFO, "Getting request & response types to export ...");

            // to load assemblies
            var toLoadCrmAssembly = new AddItemCampaignRequest();
            var toLoadXrmAssembly = new UpsertRequest();

            var reqType = typeof(OrganizationRequest);
            var resType = typeof(OrganizationResponse);

            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (var type in assembly.GetTypes())
                {
                    if (type.IsSubclassOf(reqType) || type.IsSubclassOf(resType))
                    {
                        typesToExport.Add(new ExportTypeInfo(type, ShouldBeEnhanced(type)));

                        LookForWarnings(type);
                    }
                }
            }
        }

        private static bool ShouldBeEnhanced(Type t)
        {
            var props = t
                .GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly)
                .Where(p => !typeof(ExtensionDataObject).Equals(p.PropertyType));

            bool hasDataMember = props.Count() == 0;
            foreach (var prop in props)
            {
                hasDataMember |= prop.GetCustomAttributes().Count(attrib => attrib is DataMemberAttribute) > 0;
                if (hasDataMember) break;
            }

            return !hasDataMember;
        }

        private static void LookForWarnings(Type t)
        {
            foreach (var prop in t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly))
            {
                if (prop.PropertyType.FullName.Contains("Microsoft.") &&
                    prop.PropertyType.GetCustomAttributes().Count(attrib => attrib is DataContractAttribute) > 0)
                {
                    if (ShouldBeEnhanced(prop.PropertyType))
                    {
                        warnings.Add(string.Format("{0}->{1}", t.FullName, prop.Name));
                    }
                }
            }
        }

        private static string GetSourceCode(Type t)
        {
            var sb = new StringBuilder();

            sb.AppendLine(GetClassAttributes(t));
            sb.AppendLine(GetClassHeader(t));

            foreach (var prop in t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly))
            {
                sb.AppendLine("\n\t\t[DataMember]");
                sb.AppendFormat("\t\tpublic {0} {1} {{{2}{3}}}\n",
                    GetTypeHeader(prop.PropertyType),
                    prop.Name,
                    prop.CanRead ? " get;" : "",
                    prop.CanWrite || prop.CanRead ? " set; " : " ");
            }

            sb.AppendLine("\t}\n");

            return sb.ToString();
        }

        private static string GetClassAttributes(Type t)
        {
            var sb = new StringBuilder();

            var attribs = t.GetCustomAttributesData();
            foreach (var attrib in attribs)
            {
                sb.AppendLine("\n\t" + attrib.ToString().Replace("System.Runtime.Serialization.DataContractAttribute", "DataContract"));
            }

            return sb.ToString();
        }

        private static string GetClassHeader(Type t)
        {
            var interfaces = "";
            foreach (var type in t.GetInterfaces())
            {
                interfaces += ", " + type.FullName;
            }

            if (string.IsNullOrWhiteSpace(interfaces) && t.BaseType == null)
            {
                return string.Format("\tpublic class {0}\n\t{{", t.Name);
            }
            else
            {
                return string.Format("\tpublic class {0} : {1}{2}\n\t{{", t.Name, t.BaseType.FullName, interfaces);
            }
        }

        private static string GetTypeHeader(Type t)
        {
            if (t.FullName.Contains("Nullable"))
            {
                return t.GenericTypeArguments[0].FullName + "?";
            }
            else
            if (t.ContainsGenericParameters)
            {
                throw new Exception("check " + t.FullName);
            }
            else
            {
                return t.FullName;
            }
        }

        private static void ShowWarnings()
        {
            if (warnings.Count > 0)
            {
                WriteLog(K_LOG_WARN, "The following types/properties should be reviewed:");

                foreach (var warning in warnings)
                {
                    Console.WriteLine("\t" + warning);
                }
            }
            else
            {
                WriteLog(K_LOG_OK, "There are no types/properties to review");
            }
        }

        private static string WriteSourceCodeAndInterface()
        {
            WriteLog(K_LOG_INFO, string.Format("Exporting {0} types ({1} types to be enhanced) ...", typesToExport.Count, typesToExport.Count(t => t.Enhanced)));

            Directory.CreateDirectory(@".\output");

            var methodId = 0;

            var sbIntf = new StringBuilder();
            var sbImpl = new StringBuilder();
            var sbClaz = new StringBuilder();

            sbIntf.Append("\n[ServiceContract]");
            sbIntf.AppendFormat("\npublic interface {0} {{", K_SERVICEINTF);
            sbImpl.AppendFormat("\npublic class {0} : {1} {{", K_SERVICEIMPL, K_SERVICEINTF);
            foreach (var typeToExport in typesToExport)
            {
                ++methodId;

                // intf
                sbIntf.Append("\n\n[OperationContract]");
                sbIntf.AppendFormat("\nvoid Dummy{0}({1} p);", methodId, typeToExport.GetFullName());

                // impl
                sbImpl.AppendFormat("\npublic void Dummy{0}({1} p) {{ }}", methodId, typeToExport.GetFullName());

                // claz
                if (typeToExport.Enhanced)
                {
                    sbClaz.AppendFormat("\n{0}", GetSourceCode(typeToExport.Type));
                }
            }
            sbIntf.Append("\n}");
            sbImpl.Append("\n}");

            var sbResult = new StringBuilder();
            sbResult.AppendFormat("namespace {0}\n{{\n", ExportTypeInfo.K_ENHANCEDNAMESPACE);
            sbResult.AppendLine("\tusing System.Runtime.Serialization;");
            sbResult.AppendLine("\tusing System.ServiceModel;");
            sbResult.AppendLine(sbClaz.ToString());
            sbResult.AppendLine(sbIntf.ToString());
            sbResult.AppendLine(sbImpl.ToString());
            sbResult.Append("\n}");

            var result = sbResult.ToString();

            return result;
        }

        private static Assembly BuildService(string sourceCode)
        {
            WriteLog(K_LOG_INFO, string.Format("Generating dynamic service ({0}) ...", K_SERVICEIMPL));

            var provider = new CSharpCodeProvider();
            var cp = new CompilerParameters(new[] {
                "mscorlib.dll",
                "System.Core.dll",
                "System.Runtime.Serialization.dll",
                "System.ServiceModel.dll",
                "Microsoft.Xrm.Sdk.dll",
                "Microsoft.Crm.Sdk.Proxy.dll" })
            {
                GenerateInMemory = true
            };

            var results = provider.CompileAssemblyFromSource(cp, sourceCode);

            return results.CompiledAssembly;
        }

        private static ServiceHost RunService(Assembly assembly)
        {
            var svcImpl = assembly.GetType(ExportTypeInfo.K_ENHANCEDNAMESPACE + "." + K_SERVICEIMPL);
            var svcIntf = assembly.GetType(ExportTypeInfo.K_ENHANCEDNAMESPACE + "." + K_SERVICEINTF);

            var svcHost = new ServiceHost(svcImpl, new Uri(K_SVC_URL));

            var smb = svcHost.Description.Behaviors.Find<ServiceMetadataBehavior>();
            if (smb == null)
            {
                smb = new ServiceMetadataBehavior();
                svcHost.Description.Behaviors.Add(smb);
            }
            smb.HttpGetEnabled = true;
            smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;

            svcHost.AddServiceEndpoint(
              ServiceMetadataBehavior.MexContractName,
              MetadataExchangeBindings.CreateMexHttpBinding(),
              "mex"
            );

            svcHost.AddServiceEndpoint(svcIntf, new BasicHttpBinding(), "");

            svcHost.Open();

            WriteLog(K_LOG_OK, string.Format("The service is running @ " + K_SVC_URL));

            return svcHost;
        }

        private static void DownloadAndWriteWSDL()
        {
            WriteLog(K_LOG_INFO, "Downloading WSDL to file (this might take some time - please wait) ...");

            Directory.CreateDirectory(@".\output");

            var outputFileName = string.Format(@".\output\{0}.wsdl", K_SERVICEIMPL);
            using (WebClient client = new WebClient())
            {
                File.WriteAllText(outputFileName, client.DownloadString(K_SVCWSDL));
            }

            WriteLog(K_LOG_OK, string.Format("WSDL available @ " + outputFileName));
        }

        private static void WriteLog(int level, string message)
        {
            // 0 - OK
            // 1 - INFO
            // 2 - WARN
            // 3 - ERROR
            var levelString = "[INFO]";

            switch (level)
            {
                case K_LOG_OK:
                    levelString = "[ OK ]";
                    break;

                case K_LOG_WARN:
                    levelString = "[WARN]";
                    break;

                case K_LOG_ERROR:
                    levelString = "[ERROR]";
                    break;
            }

            Console.WriteLine("\n{0} {1}", levelString, message);
        }

        private static void DisplayTongue()
        {
            Console.Clear();

            Console.WriteLine("\n\n\t       ! DO USE THAT WSDL WISELY !");
            Console.WriteLine("\n\n\t              .==++==.     .=+=.");
            Console.WriteLine("\t            +=+@@@@@@++++++@@@@@++");
            Console.WriteLine("\t          ==+=+++++@=+=++++++++@=++");
            Console.WriteLine("\t        .+++=+=+++=+=++++++=+=+==++:");
            Console.WriteLine("\t      .=++= @@@@@@&+++++@@@@&+++++++:");
            Console.WriteLine("\t    .++='     &@@@@@@@@@@@@@@@@++=+++=");
            Console.WriteLine("\t .=+=:'    .==+=.     &@@@@'++@@,. +=+=+.");
            Console.WriteLine("\t   +=++ .++=+++==  .====+=++++++=+=+ =+++'");
            Console.WriteLine("\t     :++++=@@=+ =+=+=+++++@@++++= +++++");
            Console.WriteLine("\t    ++=++@@++ +=+++==+=+@@++++= ++=+");
            Console.WriteLine("\t   +=++@@+++ +==+++===@@#+++= =++++");
            Console.WriteLine("\t  =+++@@==='+=======+@@++== +++++'");
            Console.WriteLine("\t ====@@==='=======+=@@++== =++++");
            Console.WriteLine("\t++++@@@=+.==+======@@@=== ==+=+");
            Console.WriteLine("\t++ ==@@+++=++=+====@@@+== ===++");
            Console.WriteLine("\t++ =++====+=+=+==@@@@=== =+++");
            Console.WriteLine("\t'=+=+====+=+=+==@@@=== .='");
            Console.WriteLine("\t  +==++=++=+=+=+=+==='");
            Console.WriteLine("\t    += +++=========='");
            Console.WriteLine("\t      '' =+====='");
        }
    }
}
