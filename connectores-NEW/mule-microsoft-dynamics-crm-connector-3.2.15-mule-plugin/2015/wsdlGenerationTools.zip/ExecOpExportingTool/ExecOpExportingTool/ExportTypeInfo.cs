﻿namespace ExecOpExportingTool
{
    using System;

    class ExportTypeInfo
    {
        public const string K_ENHANCEDNAMESPACE = "Enhanced.Crm.RequestResponse";

        public ExportTypeInfo(Type type, bool enhanced)
        {
            Type = type;
            Enhanced = enhanced;
        }

        public Type Type { get; set; }

        public bool Enhanced { get; set; }

        public string GetFullName()
        {
            return Enhanced ? string.Format("{0}.{1}", K_ENHANCEDNAMESPACE, Type.Name) : Type.FullName;
        }
    }
}
